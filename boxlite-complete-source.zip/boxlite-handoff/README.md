# BoxLite Sandbox Demo — source checkpoint

这是 2026-11-18 用户要求暂停时的完整代码交接。包含已完成的文件隔离实验、正在开发的真实双游戏演示、部署工具、测试脚本、历史版本和证据。

**最新游戏演示尚未完成验收。请先读 [HANDOFF.md](HANDOFF.md)，不要把 WIP 当成完成版。**

## 用户最终要什么

给 BoxLite 做 GTM/建联时可以直接展示的 demo，直观看到独立执行环境的意义：

1. 两局真正运行在 Box 内的游戏。
2. 不独立时，两局游戏在同一个 Box 内运行。
3. 在 A 内执行有错误的进程清理代码，两局都停止。
4. 独立时，一局一台 Box；相同故障代码只停止 A，B 继续运动、计分。
5. 页面要解释正常游戏代码和故障代码分别在做什么，并提供可跟随的演示。

不要转回泛营销工作台、预制落地页画板或 A/B 网络连通测试。用户特别强调“要真实运行、有代码有内容”。模型接口保留，当前不接模型 API。

## 目录

| 路径 | 内容 |
|---|---|
| `work/box-demo/play/` | 最新游戏前端，WIP |
| `work/box-demo/game_worker.py` | Box 内实际计算球位置、碰撞、得分的 Python 游戏 |
| `work/box-demo/game_backend.py` | 固定游戏启动/故障操作、真实进程验证、限时任务 |
| `work/box-demo/backend.py` | 已验证的文件隔离实验后端，后续也做了超时修改 |
| `work/box-demo/experiment.py` | 文件实验中实际写入 Box 的 A/B Python 脚本 |
| `work/box-demo/files.html` | 原文件隔离实验页面 |
| `work/box-demo/index.html` | 当前重定向到游戏前端 |
| `work/box-demo/model_adapter.py` | 预留 OpenAI-compatible 证据解释接口 |
| `work/box-root/server.py` | Box B 的 HTTP 服务与固定 API 路由 |
| `work/boxlite-connect/` | CLI/API/SDK 部署、配置和 QA 工具；保留原布局 |
| `work/launchlab/` | 用户已否定的早期落地页工作台，仅作完整历史备份 |
| `evidence/` | 文件隔离实验的真实结果/截图，以及游戏测试的部分日志 |
| `deployment/` | 无密钥的 Box 元数据 |

## 完成度

- 文件隔离实验曾通过网页实测：共享时 B 文件被删且任务失败，独立时 B 文件完整且任务成功。见 `evidence/evidence.json`。
- 真实游戏源码和前后端已编写，预览端口已配置。
- 游戏的共享模式已经实测：两局实际帧增长；故障命令停止两个游戏进程。
- 游戏的独立模式完整 QA 尚未通过；上次轮询遇到 HTTP 502。
- 最后加了控制服务活动刷新和画面响应竞争修复，但最后部署在用户暂停时被中断，远程最终状态未确认。
- 自动演示、游戏浏览器画面、移动端和重连体验尚需验证。

## 在另一台电脑继续

保留此仓库的 `work/` 布局；脚本用相对目录定位源码。

```sh
python3 -m venv work/boxlite-connect/venv
. work/boxlite-connect/venv/bin/activate
python -m pip install -r requirements.txt
cp work/boxlite-connect/credentials.example.json work/boxlite-connect/credentials.json
cp work/boxlite-connect/controller-config.example.json work/boxlite-connect/controller-config.json
```

通过本机私密方式填写自己的 BoxLite Key。两个真实配置文件已被 `.gitignore` 排除，**不要提交密钥**。

准备确认部署时：

```sh
python work/boxlite-connect/setup_game_tunnels.py
python work/boxlite-connect/deploy_isolation.py
mkdir -p outputs/box-demo
python work/boxlite-connect/qa_games.py
```

这些命令会修改现有演示 Box，启动或停止本演示的游戏进程；请先读接手说明，确认当前远程状态。只想看静态 UI 可用普通 HTTP 静态服务，但真实执行后端必须在 Box 中，静态预览不等于 live demo。

## 已知运行地址

- 文件/入口：<https://8080-d-4e6a656b374551457035374d.proxy.boxlite.ai/isolation/>
- 最新游戏：<https://8080-d-4e6a656b374551457035374d.proxy.boxlite.ai/isolation/play/>
- 原文件实验：<https://8080-d-4e6a656b374551457035374d.proxy.boxlite.ai/isolation/files.html>

Box 保留闲置 300 秒自动停止；地址可能需要唤醒，不保证暂停后一直在线。

## 凭据与依赖

- Python SDK：`boxlite==0.11.0`；网页和游戏本身只依赖 Python 标准库。
- 部署 SDK 在本机运行；Box B 用 REST API 调度 Box A。
- 用户已明确允许 BoxLite API Key 保存在 Box B 服务端私密文件中，仅用于固定演示。
- 密钥不在仓库/归档内，前端不含密钥。远程配置路径见 HANDOFF。
- 不包含虚拟环境、官方 SDK 二进制、包缓存或实际认证配置。
