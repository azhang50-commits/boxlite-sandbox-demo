import asyncio,json
from pathlib import Path
from datetime import datetime,timezone
from playwright.async_api import async_playwright

async def main():
    root=Path(__file__).resolve().parent
    out=root/'qa-results'
    out.mkdir(exist_ok=True)
    results=[]
    errors=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu'])
        page=await browser.new_page(viewport={'width':1440,'height':1100},device_scale_factor=1)
        page.on('pageerror',lambda error:errors.append(str(error)))
        await page.goto('http://127.0.0.1:8080',wait_until='networkidle')
        await page.locator('#preview').content_frame.locator('h1').wait_for()
        for width in [1440,768,390]:
            await page.set_viewport_size({'width':width,'height':1100})
            await page.screenshot(path=str(out/f'workbench-{width}.png'),full_page=True)
            overflow=await page.evaluate('document.documentElement.scrollWidth > innerWidth')
            assert not overflow,f'Workbench overflow at {width}'
            results.append({'test':'workbench layout','width':width,'pass':not overflow})
        await page.set_viewport_size({'width':1440,'height':1100})
        titles=[]
        for i in range(3):
            await page.locator(f'[data-variant="{i}"]').click()
            frame=page.locator('#preview').content_frame
            await frame.locator(f'body.theme-{["startup","enterprise","platform"][i]}').wait_for()
            titles.append(await frame.locator('h1').inner_text())
            results.append({'test':'variant switching','variant':'ABC'[i],'pass':True})
        assert len(set(titles))==3,'Variants should have distinct messages'
        await page.locator('[data-variant="0"]').click()
        await page.locator('[data-width="390px"]').click()
        assert await page.locator('#preview').evaluate('(e)=>e.getBoundingClientRect().width')==390
        await page.locator('[data-width="100%"]').click()
        await page.locator('#briefForm [name=product]').fill('TaskNest')
        await page.locator('#briefForm [name=description]').fill('A demo workspace for marketing experiments.')
        await page.locator('#briefForm [type=submit]').click()
        await page.locator('#preview').content_frame.locator('h1').filter(has_text='TaskNest').wait_for()
        await page.reload(wait_until='networkidle')
        assert await page.locator('#briefForm [name=product]').input_value()=='TaskNest'
        results.append({'test':'brief updates and persists','pass':True})
        async with page.expect_download() as event:
            await page.locator('#exportBtn').click()
        download=await event.value
        await download.save_as(str(out/'exported-example.html'))
        exported=(out/'exported-example.html').read_text()
        assert 'TaskNest' in exported and 'leadForm' in exported and '<style>' in exported
        results.append({'test':'download standalone HTML','pass':True})
        await page.locator('#historyBtn').click()
        assert await page.locator('#briefForm [name=product]').input_value()=='BoxLite'
        await page.locator('#checkBtn').click()
        await page.locator('#modalTitle').filter(has_text='页面检查报告').wait_for(timeout=90000)
        await page.locator('#downloadReport').wait_for(timeout=90000)
        report_text=await page.locator('#modalBody').inner_text()
        assert '54 / 54' in report_text,report_text
        async with page.expect_download() as event:
            await page.locator('#downloadReport').click()
        await (await event.value).save_as(str(out/'browser-dom-report.json'))
        results.append({'test':'live browser audit of 9 variant/viewport combinations','checks':54,'pass':True})
        await page.screenshot(path=str(out/'check-report.png'),full_page=True)
        await page.locator('#closeModal').click()
        for i in range(3):
            await page.goto(f'http://127.0.0.1:8080/preview.html?v={i}',wait_until='networkidle')
            for width in [390,768,1440]:
                await page.set_viewport_size({'width':width,'height':1000})
                assert not await page.evaluate('document.documentElement.scrollWidth > innerWidth'),f'Variant {i} overflow at {width}'
                await page.locator('[data-primary-cta]').click()
                assert await page.locator('#leadForm').is_visible()
                await page.locator('[name=email]').fill('qa@example.com')
                await page.locator('[name=task]').fill('Checking the demo form only')
                await page.locator('#leadForm button').click()
                assert await page.locator('#formSuccess').is_visible()
                results.append({'test':'standalone page layout and form','variant':'ABC'[i],'width':width,'pass':True})
                await page.evaluate('scrollTo(0,0)')
                if width in [390,1440]:
                    await page.screenshot(path=str(out/f'variant-{i}-{width}.png'),full_page=True)
        await browser.close()
    assert not errors,errors
    report={'checked_at':datetime.now(timezone.utc).isoformat(),'environment':'Chromium headless inside BoxLite microVM','scope':'Actual localhost HTTP app; external proxy health checked separately. No conversion prediction.','results':results,'page_errors':errors,'pass':True}
    (out/'release-report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report),flush=True)

asyncio.run(main())
