import asyncio,json
from pathlib import Path
import boxlite
ROOT=Path(__file__).resolve().parent
c=json.loads((ROOT/'credentials.json').read_text())
async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=c['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(c['BOXLITE_API_KEY'])))
    box=await rt.get(json.loads((ROOT/'deployment.json').read_text())['box_id'])
    await box.stop()
    print('STOPPED',flush=True)
    await box.start()
    print('STARTED',flush=True)
asyncio.run(main())
