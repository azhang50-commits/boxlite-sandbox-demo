import asyncio,json
from pathlib import Path
import boxlite
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'credentials.json').read_text())
async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    box=await rt.get(json.loads((ROOT/'deployment.json').read_text())['box_id'])
    execution=await box.exec('python3',args=['-c',"import pathlib,urllib.request; print('FILES', [p.name for p in pathlib.Path('/app').glob('*')]); print('HEALTH',urllib.request.urlopen('http://127.0.0.1:8080/healthz',timeout=5).read().decode())"])
    async for text in execution.stdout():
        print(text,flush=True)
    async for text in execution.stderr():
        print(text,flush=True)
    print('EXIT', (await execution.wait()).exit_code,flush=True)
asyncio.run(main())
