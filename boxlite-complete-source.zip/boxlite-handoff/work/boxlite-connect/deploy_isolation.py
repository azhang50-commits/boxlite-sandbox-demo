import asyncio,json,os
from pathlib import Path
import boxlite
from manage import request
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'credentials.json').read_text())
public=(ROOT/'public-url.txt').read_text().strip()
controller=json.loads((ROOT/'deployment.json').read_text())['box_id']
local_config=ROOT/'controller-config.json'
previous=json.loads(local_config.read_text()) if local_config.exists() else {}
fd=os.open(local_config,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
with os.fdopen(fd,'w') as out:
    json.dump({**previous,'url':config['BOXLITE_REST_URL'],'key':config['BOXLITE_API_KEY'],'worker':'FouKpyrRRw8u','controller':controller,'origin':public},out)

async def execute(box,command,args):
    created=request('POST','/v1/boxes/'+controller+'/exec',{'command':command,'args':args,'user':'root','timeout_secs':30})
    for n in range(30):
        result=request('GET','/v1/boxes/'+controller+'/executions/'+created['execution_id'])
        if result.get('status')=='completed':
            if result.get('exit_code')!=0:
                raise RuntimeError('Deployment command failed: '+str(result.get('exit_code')))
            return 'DEPLOYMENT_COMMAND_OK'
        await asyncio.sleep(.5)
    raise RuntimeError('Deployment command timed out')

async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    box=await rt.get(controller)
    if request('GET','/v1/boxes/'+controller).get('status') in ('stopped','configured','created'):
        await box.start()
    await execute(box,'mkdir',['-p','/app/isolation','/home/boxlite/box-meaning-private'])
    await box.copy_in(str(ROOT.parent/'box-demo')+'/.','/app/isolation')
    await box.copy_in(str(local_config),'/home/boxlite/box-meaning-private/config.json')
    await execute(box,'chmod',['600','/home/boxlite/box-meaning-private/config.json'])
    await box.copy_in(str(ROOT.parent/'box-root'/'server.py'),'/app/server.py')
    code="import os,signal,pathlib; targets=[]\nfor p in pathlib.Path('/proc').glob('[0-9]*/cmdline'):\n try:\n  args=p.read_bytes().split(bytes([0]));\n  if args[:3]==[b'python3',b'-u',b'/app/server.py']: targets.append(int(p.parent.name))\n except OSError: pass\nfor pid in targets: os.kill(pid,signal.SIGTERM)\nprint('SERVER_RESTART_REQUESTED',len(targets))"
    print(await execute(box,'python3',['-c',code]),flush=True)
    print('DEPLOYED',public+'/isolation/',flush=True)

async def retry():
    for n in range(3):
        try:
            return await main()
        except boxlite.errors.NetworkError:
            if n==2:raise
            await asyncio.sleep(2)
asyncio.run(retry())
