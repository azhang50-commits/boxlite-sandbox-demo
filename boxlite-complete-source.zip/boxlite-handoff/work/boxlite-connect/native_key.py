import json
import os
import subprocess
from pathlib import Path

script = '''tell application "System Events"
activate
set response to display dialog "请输入 BoxLite API Key。密钥仅保存到本机权限受限的文件，不会发送到聊天记录。" default answer "" with hidden answer buttons {"取消", "保存"} default button "保存" with title "连接 BoxLite"
return text returned of response
end tell'''
result = subprocess.run(['osascript', '-e', script], capture_output=True, text=True)
if result.returncode:
    print('INPUT_CANCELLED_OR_UNAVAILABLE', flush=True)
    raise SystemExit(1)
key = result.stdout.strip()
if not key.startswith('blk_') or len(key) < 16 or any(c.isspace() for c in key):
    print('INVALID_KEY_FORMAT', flush=True)
    raise SystemExit(1)
root = Path(__file__).resolve().parent
os.chmod(root, 0o700)
fd = os.open(root / 'credentials.json', os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
os.fchmod(fd, 0o600)
with os.fdopen(fd, 'w') as out:
    json.dump({'BOXLITE_REST_URL': 'https://api.boxlite.ai', 'BOXLITE_API_KEY': key}, out)
print('CREDENTIAL_SAVED', flush=True)
