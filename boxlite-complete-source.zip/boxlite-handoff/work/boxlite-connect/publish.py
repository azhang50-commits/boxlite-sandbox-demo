import asyncio
import json
from pathlib import Path
import boxlite

ROOT = Path(__file__).resolve().parent
config = json.loads((ROOT / 'credentials.json').read_text())
async def main():
    rt = boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    box_id = json.loads((ROOT / 'deployment.json').read_text())['box_id']
    box = await rt.get(box_id)
    if box is None:
        raise RuntimeError('Deployment box not found')
    print('SDK_CONNECTED', flush=True)
    await box.network.update_inbound(boxlite.InboundNetworkSpec(mode='enabled'))
    tunnel = await box.network.tunnel(('127.0.0.1',8080))
    url=tunnel.uri()
    (ROOT / 'public-url.txt').write_text(url)
    print('PUBLIC_URL:', url, flush=True)

asyncio.run(main())
