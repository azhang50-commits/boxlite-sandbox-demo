import json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
origin=(ROOT/'public-url.txt').read_text().strip()

def get(url,payload=None,timeout=12):
    args=['/usr/bin/curl','-sS','--max-time',str(timeout),'-w','\n%{http_code}']
    if payload is not None:args+=['-X','POST','-H','Content-Type: application/json','-H','X-Demo-Request: 1','-d',json.dumps(payload)]
    for attempt in range(4 if payload is None else 1):
        r=subprocess.run(args+[url],capture_output=True,text=True)
        body,_,status=r.stdout.rpartition('\n')
        if not r.returncode and status.startswith('2'):
            return json.loads(body)
        time.sleep(.5)
    raise RuntimeError('HTTP request not ready: '+status)

def operation(action,mode):
    value=get(origin+'/isolation/api/game/'+action,{'mode':mode})
    end=time.monotonic()+85
    while time.monotonic()<end:
        time.sleep(.6)
        job=get(origin+'/isolation/api/game/job?id='+value['job_id'])
        if job['state']=='done':return job['session']
        if job['state']=='error':raise RuntimeError(job['message'])
    raise RuntimeError('Game operation timed out')

results=[]
for mode in ['shared','isolated']:
    session=operation('start',mode)
    print('STARTED',mode,session['id'],flush=True)
    a=get(session['a']['url']+'/state')
    b1=get(session['b']['url']+'/state')
    time.sleep(.3)
    b2=get(session['b']['url']+'/state')
    assert a['round']==b1['round']==b2['round']==session['id']
    assert b2['tick']>b1['tick']
    broken=operation('fault',mode)
    assert broken['fault']['verified']
    assert broken['a']['pid'] in broken['fault']['killed_pids']
    if mode=='shared':
        assert broken['b']['pid'] in broken['fault']['killed_pids']
    else:
        b3=get(session['b']['url']+'/state')
        assert b3['tick']>b2['tick']
        assert session['a']['box_id']!=session['b']['box_id']
    results.append({'mode':mode,'started_session':session,'fault_session':broken,'initial_b_ticks':[b1['tick'],b2['tick']],'pass':True})
    print('VERIFIED',mode,'killed',broken['fault']['killed_pids'],'B_STOPPED',broken['fault']['b_stopped'],flush=True)
out=ROOT.parent.parent/'outputs'/'box-demo'/'game-evidence.json'
out.write_text(json.dumps({'checked_at':time.time(),'results':results,'pass':True},indent=2))
print('REAL_GAME_EVIDENCE_SAVED',flush=True)
