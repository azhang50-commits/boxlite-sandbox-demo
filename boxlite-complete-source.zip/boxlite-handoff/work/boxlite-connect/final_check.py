import json,subprocess,time
from pathlib import Path
from manage import request
ROOT=Path(__file__).resolve().parent
box_id=json.loads((ROOT/'deployment.json').read_text())['box_id']
info=request('GET','/v1/boxes/'+box_id)
print('BOX_STATUS',info.get('status'),flush=True)
if info.get('status')=='stopped':
    request('POST','/v1/boxes/'+box_id+'/start',{})
    print('BOX_STARTED',flush=True)
url=(ROOT/'public-url.txt').read_text().strip()
for attempt in range(3):
    response=subprocess.run(['/usr/bin/curl','-fsSL','--max-time','15',url+'/'],capture_output=True)
    if response.returncode==0 and b'LaunchLab' in response.stdout:
        (ROOT/'final-live-index.html').write_bytes(response.stdout)
        print('LIVE_WORKBENCH_VERIFIED',flush=True)
        break
    print('PROXY_RETRY',attempt+1,flush=True)
    time.sleep(2)
else:
    print('PROXY_NOT_READY',flush=True)
