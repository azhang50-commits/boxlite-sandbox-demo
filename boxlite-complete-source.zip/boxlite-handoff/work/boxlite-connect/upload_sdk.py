import asyncio,json
from pathlib import Path
import boxlite
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'credentials.json').read_text())
async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    box=await rt.get(json.loads((ROOT/'deployment.json').read_text())['box_id'])
    execution=await box.exec('mkdir',args=['-p','/app'],user='root')
    async for text in execution.stderr():
        print(text,flush=True)
    result=await execution.wait()
    print('MKDIR_EXIT',result.exit_code,flush=True)
    if result.exit_code:
        raise RuntimeError('Could not create app path')
    await box.copy_in(str(ROOT.parent/'launchlab')+'/.','/app')
    print('COPY_COMPLETED',flush=True)
async def with_retry():
    for attempt in range(3):
        try:
            return await main()
        except boxlite.errors.NetworkError:
            if attempt == 2:
                raise
            print('TRANSIENT_NETWORK_RETRY',attempt+1,flush=True)
            await asyncio.sleep(2)
asyncio.run(with_retry())
