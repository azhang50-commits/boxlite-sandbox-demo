import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / 'credentials.json').read_text())

def request(method, path, payload=None):
    cfg = 'header = ' + json.dumps('Authorization: Bearer ' + CONFIG['BOXLITE_API_KEY']) + '\n'
    args = ['/usr/bin/curl', '--config', '-', '--silent', '--show-error', '--max-time', '60',
            '--request', method, '--write-out', '\n%{http_code}']
    if payload is not None:
        cfg += 'header = "Content-Type: application/json"\ndata = ' + json.dumps(json.dumps(payload)) + '\n'
    result = subprocess.run(args + [CONFIG['BOXLITE_REST_URL'] + path], input=cfg, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError('Transport failed, curl code ' + str(result.returncode))
    body, _, status = result.stdout.rpartition('\n')
    try:
        data = json.loads(body)
    except ValueError:
        data = {'response': body[:300]}
    if not 200 <= int(status) < 300:
        raise RuntimeError(json.dumps({'status': status, 'error': data}))
    return data

if __name__ == '__main__':
    data = request(sys.argv[1], sys.argv[2], json.loads(sys.argv[3]) if len(sys.argv) > 3 else None)
    print(json.dumps(data, ensure_ascii=False))
