import json
import os
import secrets
from pathlib import Path
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

ROOT = Path(__file__).resolve().parent
os.chmod(ROOT, 0o700)
TOKEN = secrets.token_urlsafe(32)
ROUTE = '/' + TOKEN
PAGE = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>连接 BoxLite</title><style>body{font:16px system-ui;background:#f4f6f8;color:#17212d;max-width:540px;margin:12vh auto;padding:24px}main{background:white;padding:32px;border-radius:18px;box-shadow:0 10px 40px #0001}input,button{box-sizing:border-box;width:100%;padding:14px;margin-top:16px;border-radius:8px;border:1px solid #ccd3dc;font:inherit}button{background:#17212d;color:white;cursor:pointer}p{line-height:1.7;color:#526070}</style><main><h1>连接 BoxLite</h1><p>此页面仅在你的电脑上运行。密钥将保存到本机权限受限的文件，用于后续连接 BoxLite；不会写入聊天记录。</p><form method="post"><label for="key">BoxLite API Key</label><input id="key" name="key" type="password" autocomplete="off" placeholder="blk_live_…" required><button>保存密钥</button></form><p>本次仅保存凭据，不创建或运行云端资源。</p></main></html>'''

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, status, body):
        self.send_response(status)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body.encode())

    def valid_request(self):
        return self.path == ROUTE and self.headers.get('Host') == f'127.0.0.1:{self.server.server_port}'

    def do_GET(self):
        if not self.valid_request():
            return self.reply(404, 'Not found')
        self.reply(200, PAGE)

    def do_POST(self):
        if not self.valid_request():
            return self.reply(403, 'Forbidden')
        origin = self.headers.get('Origin')
        if origin and origin != f'http://127.0.0.1:{self.server.server_port}':
            return self.reply(403, 'Forbidden')
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length < 8192:
                return self.reply(400, 'Invalid request')
            key = parse_qs(self.rfile.read(length).decode()).get('key', [''])[0].strip()
            if not key.startswith('blk_') or len(key) < 16 or any(c.isspace() for c in key):
                return self.reply(400, '<meta charset="utf-8"><p>密钥格式似乎不正确，请返回重新填写。</p>')
            fd = os.open(ROOT / 'credentials.json', os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, 'w') as out:
                json.dump({'BOXLITE_REST_URL': 'https://api.boxlite.ai', 'BOXLITE_API_KEY': key}, out)
            self.reply(200, '<meta charset="utf-8"><title>已保存</title><main style="font:18px system-ui;max-width:540px;margin:15vh auto;padding:24px"><h1>密钥已安全保存到本机</h1><p>可以关闭此页面，返回聊天告诉我“已提交”。</p><p>尚未创建云端资源。</p></main>')
            print('CREDENTIAL_SAVED', flush=True)
        except (ValueError, UnicodeError):
            self.reply(400, 'Invalid request')

server = HTTPServer(('127.0.0.1', 0), Handler)
print(f'http://127.0.0.1:{server.server_port}{ROUTE}', flush=True)
server.serve_forever()
