import json
import urllib.request
import urllib.error
import subprocess
from pathlib import Path

config = json.loads((Path(__file__).resolve().parent / 'credentials.json').read_text())
request = urllib.request.Request(
    config['BOXLITE_REST_URL'] + '/v1/boxes',
    headers={'Authorization': 'Bearer ' + config['BOXLITE_API_KEY'], 'Accept': 'application/json'},
)
try:
    with urllib.request.urlopen(request, timeout=25) as response:
        print('HTTP_STATUS:', response.status)
        print('JSON_RESPONSE:', 'json' in response.headers.get('Content-Type', ''))
        data = json.load(response)
        if isinstance(data, list):
            print('BOX_COUNT:', len(data))
        elif isinstance(data, dict):
            for field in ('boxes', 'items', 'data'):
                if isinstance(data.get(field), list):
                    print('BOX_COUNT:', len(data[field]))
                    break
        print('READ_ONLY_CONNECTION_OK')
except urllib.error.HTTPError as exc:
    print('HTTP_STATUS:', exc.code)
except urllib.error.URLError as exc:
    # Apple's curl uses the system trust store rather than Python's separate CA bundle.
    curl_config = 'header = ' + json.dumps('Authorization: Bearer ' + config['BOXLITE_API_KEY']) + '\n'
    result = subprocess.run(
        ['/usr/bin/curl', '--config', '-', '--silent', '--show-error', '--max-time', '25',
         '--write-out', '\n%{http_code}', config['BOXLITE_REST_URL'] + '/v1/boxes'],
        input=curl_config, capture_output=True, text=True,
    )
    if result.returncode:
        print('CONNECTION_FAILED_CURL_CODE:', result.returncode)
    else:
        body, _, status = result.stdout.rpartition('\n')
        print('HTTP_STATUS:', status)
        if status == '200':
            json.loads(body)
            print('READ_ONLY_CONNECTION_OK')
