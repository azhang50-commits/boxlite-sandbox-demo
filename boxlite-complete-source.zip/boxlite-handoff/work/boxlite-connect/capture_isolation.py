import asyncio,hashlib,json,sys,uuid
from datetime import datetime,timezone
from pathlib import Path
import boxlite
from manage import request
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'box-demo'))
from experiment import worker_script,SCRIPT_HASH,SYNTHETIC_VALUE
config=json.loads((ROOT/'credentials.json').read_text())
controller=json.loads((ROOT/'deployment.json').read_text())['box_id']
worker='FouKpyrRRw8u'

async def execute(box,code):
    execution=await box.exec('python3',args=['-c',code],user='root',timeout_secs=30)
    async def read(stream):
        result=''
        async for line in stream:result+=line
        return result
    stdout,stderr=await asyncio.gather(read(execution.stdout()),read(execution.stderr()))
    result=await execution.wait()
    if result.exit_code:
        raise RuntimeError('Experiment failed: '+str(result.exit_code)+' '+stderr[:500])
    return json.loads(stdout),execution.id()

async def main():
    for bid in [worker,controller]:
        info=request('GET','/v1/boxes/'+bid)
        if info['status']=='stopped':request('POST','/v1/boxes/'+bid+'/start',{})
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    a,b=await rt.get(worker),await rt.get(controller)
    run_id=uuid.uuid4().hex[:12]
    base='/home/boxlite/isolation-lab/'+run_id
    shared,eid=await execute(a,worker_script(base+'/shared',True,base+'/shared/result.json'))
    shared.update(box_id=worker,execution_id=eid,phase='shared')
    print('SHARED_MEASURED',flush=True)
    private=base+'/isolated/customer-b/private.txt'
    before,_=await execute(b,"import json,hashlib;from pathlib import Path;p=Path("+repr(private)+");p.parent.mkdir(parents=True,exist_ok=True);p.write_text("+repr(SYNTHETIC_VALUE)+");print(json.dumps({'sha':hashlib.sha256(p.read_bytes()).hexdigest()}))")
    isolated,eid=await execute(a,worker_script(base+'/isolated',False,base+'/isolated/result.json'))
    after,_=await execute(b,"import json,hashlib;from pathlib import Path;p=Path("+repr(private)+");print(json.dumps({'exists':p.exists(),'sha':hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None,'kernel':hashlib.sha256(Path('/proc/sys/kernel/random/boot_id').read_bytes()).hexdigest()[:12]}))")
    isolated.update(box_id=worker,execution_id=eid,phase='isolated',b_box_id=controller,b_file_exists_after=after['exists'],b_file_unchanged=before['sha']==after['sha'],b_kernel_fingerprint=after['kernel'])
    verified=shared['leads']==isolated['leads']==70 and shared['cross_read']['succeeded'] and shared['cross_delete']['succeeded'] and not isolated['cross_read']['succeeded'] and not isolated['cross_delete']['succeeded'] and isolated['b_file_unchanged']
    report={'run_id':run_id,'checked_at':datetime.now(timezone.utc).isoformat(),'verified':verified,'live':True,'script_sha256':SCRIPT_HASH,'shared':shared,'isolated':isolated,'scope':'Synthetic read/delete test. Both modes use BoxLite. Shared mode intentionally has no per-task filesystem access control.'}
    (ROOT.parent/'box-demo'/'last-run.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print('EVIDENCE_VERIFIED',verified,flush=True)
    print('INDEPENDENT_KERNEL_FINGERPRINTS',isolated['kernel_fingerprint'],isolated['b_kernel_fingerprint'],flush=True)
    if not verified:raise RuntimeError('Expected isolation behavior did not verify')
asyncio.run(main())
