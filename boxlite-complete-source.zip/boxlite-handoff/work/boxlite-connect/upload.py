import base64
import io
import json
import tarfile
from pathlib import Path
from manage import request

ROOT=Path(__file__).resolve().parent
deployment={'box_id':'nOaK7jwG7l9O','name':'launchlab-demo-20261118','auto_stop':300,'port':8080}
(ROOT/'deployment.json').write_text(json.dumps(deployment))
source=ROOT.parent/'launchlab'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
    for file in source.iterdir():
        if file.is_file():
            archive.add(file,arcname=file.name)
payload=base64.b64encode(buffer.getvalue()).decode()
code="import base64,io,tarfile,pathlib; p=pathlib.Path('/app'); p.mkdir(exist_ok=True); tarfile.open(fileobj=io.BytesIO(base64.b64decode("+repr(payload)+")),mode='r:gz').extractall(p,filter='data'); print('uploaded')"
response=request('POST','/v1/boxes/'+deployment['box_id']+'/exec',{'command':'python3','args':['-c',code]})
(ROOT/'upload-execution.json').write_text(json.dumps(response))
print(json.dumps(response))
