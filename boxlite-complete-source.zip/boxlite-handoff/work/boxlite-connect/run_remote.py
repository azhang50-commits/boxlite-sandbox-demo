import asyncio,json,sys
from pathlib import Path
import boxlite
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'credentials.json').read_text())
async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=config['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(config['BOXLITE_API_KEY'])))
    box=await rt.get(json.loads((ROOT/'deployment.json').read_text())['box_id'])
    execution=await box.exec('sh',args=['-c',sys.argv[1]],user='root',timeout_secs=600)
    print('EXECUTION_ID',execution.id,flush=True)
    async def consume(stream,label):
        async for line in stream:
            print(label,line,flush=True)
    await asyncio.gather(consume(execution.stdout(),'OUT'),consume(execution.stderr(),'ERR'))
    result=await execution.wait()
    print('EXIT',result.exit_code,flush=True)
    sys.exit(result.exit_code or 0)
asyncio.run(main())
