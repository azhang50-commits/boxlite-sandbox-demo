import asyncio,json
from pathlib import Path
import boxlite
from manage import request
ROOT=Path(__file__).resolve().parent
c=json.loads((ROOT/'credentials.json').read_text())
controller=json.loads((ROOT/'deployment.json').read_text())['box_id']
worker='FouKpyrRRw8u'
async def main():
    rt=boxlite.Boxlite.rest(boxlite.BoxliteRestOptions(url=c['BOXLITE_REST_URL'],credential=boxlite.ApiKeyCredential(c['BOXLITE_API_KEY'])))
    for bid in [worker,controller]:
        state=request('GET','/v1/boxes/'+bid)['status']
        if state in ('stopped','configured','created'):request('POST','/v1/boxes/'+bid+'/start',{})
    a,b=await rt.get(worker),await rt.get(controller)
    await a.network.update_inbound(boxlite.InboundNetworkSpec(mode='enabled'))
    urls={}
    for name,box,port in [('a',a,9101),('shared_b',a,9102),('isolated_b',b,9102)]:
        tunnel=await box.network.tunnel(('127.0.0.1',port))
        urls[name]=tunnel.uri()
        print(name,urls[name],flush=True)
    path=ROOT/'controller-config.json'
    current=json.loads(path.read_text())
    current['game_urls']=urls
    path.write_text(json.dumps(current))
    path.chmod(0o600)
asyncio.run(main())
