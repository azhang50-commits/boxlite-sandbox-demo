"""Fixed demo operations only. No arbitrary code or process names are accepted from the browser."""
import base64
import io
import json
import os
import signal
import subprocess
import tarfile
import threading
import time
import urllib.request
import uuid
from pathlib import Path
import backend

HERE=Path(__file__).resolve().parent
GAME_ROOT=Path('/home/boxlite/game-lab')
GAME_SCRIPT=str(GAME_ROOT/'game_worker.py')
GAME_JOBS={}
GAME_LOCK=threading.Lock()
CURRENT=None

# The intentionally over-broad cleanup command is identical in both modes.
FAULT_CODE='''import json,os,signal
from pathlib import Path
target = "/home/boxlite/game-lab/game_worker.py"
killed = []
for entry in Path("/proc").glob("[0-9]*/cmdline"):
    try:
        command = entry.read_bytes().split(bytes([0]))
        if len(command)>1 and command[1].decode(errors="ignore")==target:
            pid = int(entry.parent.name)
            os.kill(pid, signal.SIGTERM)
            killed.append(pid)
    except (OSError,ValueError):
        pass
result = {"killed_pids": killed, "scope": "demo game processes in this Box only"}
'''

class GameEngine(backend.Engine):
    def __init__(self,config):
        super().__init__(config)
        self.deadline=time.monotonic()+65
    def api(self,method,path,data=None,raw=False):
        remaining=self.deadline-time.monotonic()
        if remaining<=0:
            raise backend.DemoError('本次操作超过 65 秒，已停止等待。请重新启动演示。')
        req=urllib.request.Request(self.config['url'].rstrip('/')+path,
            data=json.dumps(data).encode() if data is not None else None,
            headers={'Authorization':'Bearer '+self.config['key'],'Content-Type':'application/json'},method=method)
        try:
            with urllib.request.urlopen(req,timeout=min(8,remaining)) as response:
                payload=response.read()
        except Exception:
            raise backend.DemoError('BoxLite 连接未完成，请重新启动；本次没有生成成功结果。') from None
        return payload if raw else json.loads(payload) if payload else {}

    def execute(self,code,filename):
        output=str(GAME_ROOT/filename)
        full=code+"\nfrom pathlib import Path\nPath("+repr(output)+").write_text(json.dumps(result))\n"
        created=self.api('POST','/v1/boxes/'+self.config['worker']+'/exec',
            {'command':'python3','args':['-c',full],'user':'root','timeout_secs':20})
        execution=created['execution_id']
        until=time.monotonic()+18
        while time.monotonic()<until:
            state=self.api('GET','/v1/boxes/'+self.config['worker']+'/executions/'+execution)
            if state.get('status')=='completed':
                if state.get('exit_code')!=0:
                    raise backend.DemoError('游戏操作未成功，退出码 '+str(state.get('exit_code')))
                break
            time.sleep(.25)
        else:
            raise backend.DemoError('Box 内游戏操作超时，请重新启动演示。')
        archive=self.api('GET','/v1/boxes/'+self.config['worker']+'/files?path='+output,raw=True)
        with tarfile.open(fileobj=io.BytesIO(archive),mode='r:*') as data:
            file=next((x for x in data.getmembers() if x.isfile() and x.name.endswith(filename)),None)
            if file is None:
                raise backend.DemoError('未收到游戏操作结果')
            result=json.load(data.extractfile(file))
        result['execution_id']=execution
        return result

    def touch_controller(self):
        # Refresh the controller's activity clock only on explicit demo operations.
        self.api('POST','/v1/boxes/'+self.config['controller']+'/exec',
            {'command':'true','args':[],'timeout_secs':5})

def kill_local_games():
    killed=[]
    for entry in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            args=entry.read_bytes().split(bytes([0]))
            if len(args)>1 and args[1].decode(errors='ignore')==GAME_SCRIPT:
                pid=int(entry.parent.name)
                os.kill(pid,signal.SIGTERM)
                killed.append(pid)
        except (OSError,ValueError):
            pass
    return killed

def wait_local(port):
    for i in range(25):
        try:
            with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/state',timeout=.25) as response:
                return json.load(response)
        except Exception:
            time.sleep(.1)
    raise backend.DemoError('B 的游戏没有启动成功')

def setup_remote_code(round_id,mode,config):
    source=base64.b64encode((HERE/'game_worker.py').read_bytes()).decode()
    specs=[{'label':'A','port':9101}]+([{'label':'B','port':9102}] if mode=='shared' else [])
    return FAULT_CODE+'''
import base64,subprocess,sys,time,urllib.request
root=Path('/home/boxlite/game-lab')
root.mkdir(parents=True,exist_ok=True)
script=root/'game_worker.py'
script.write_bytes(base64.b64decode(%r))
time.sleep(.3)
states={}
for spec in %r:
    log=(root/('game-'+spec['label']+'.log')).open('ab')
    subprocess.Popen([sys.executable,str(script),'--port',str(spec['port']),'--label',spec['label'],'--box-id',%r,'--round',%r],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
    for attempt in range(25):
        try:
            with urllib.request.urlopen('http://127.0.0.1:'+str(spec['port'])+'/state',timeout=.25) as response:
                value=json.load(response)
            if value['round']==%r:
                states[spec['label']]=value
                break
        except Exception:
            pass
        time.sleep(.1)
    else:
        raise RuntimeError('Game did not start')
result={'states':states}
''' % (source,specs,config['worker'],round_id,round_id)

def start_games(mode,notify):
    global CURRENT
    c=backend.config()
    if not c.get('game_urls'):
        raise backend.DemoError('游戏运行地址尚未配置')
    engine=GameEngine(c)
    engine.touch_controller()
    notify('连接 Box A，准备真实游戏进程')
    engine.ensure_running()
    round_id=uuid.uuid4().hex[:12]
    notify('在 Box A 启动游戏'+(' A 和 B' if mode=='shared' else ' A'))
    remote=engine.execute(setup_remote_code(round_id,mode,c),'setup-'+round_id+'.json')
    kill_local_games()
    if mode=='isolated':
        notify('在独立 Box B 启动游戏 B')
        GAME_ROOT.mkdir(parents=True,exist_ok=True)
        (GAME_ROOT/'game_worker.py').write_bytes((HERE/'game_worker.py').read_bytes())
        with (GAME_ROOT/'game-B.log').open('ab') as log:
            subprocess.Popen([os.sys.executable,GAME_SCRIPT,'--port','9102','--label','B','--box-id',c['controller'],'--round',round_id],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True)
        b=wait_local(9102)
    else:
        b=remote['states']['B']
    a=remote['states']['A']
    CURRENT={'id':round_id,'mode':mode,'state':'running','started_at':time.time(),
        'a':{'box_id':c['worker'],'url':c['game_urls']['a'],'pid':a['pid']},
        'b':{'box_id':c['worker'] if mode=='shared' else c['controller'],'url':c['game_urls']['shared_b'] if mode=='shared' else c['game_urls']['isolated_b'],'pid':b['pid']},
        'start_ticks':{'a':a['tick'],'b':b['tick']},'setup_execution_id':remote['execution_id']}
    save_current()
    return CURRENT

def fault_games(notify):
    global CURRENT
    if not CURRENT or CURRENT['state']!='running':
        raise backend.DemoError('请先启动两局游戏')
    c=backend.config()
    engine=GameEngine(c)
    engine.touch_controller()
    notify('在 A 所在 Box 内执行错误的游戏进程清理代码')
    result=engine.execute(FAULT_CODE,'fault-'+CURRENT['id']+'.json')
    if CURRENT['a']['pid'] not in result['killed_pids']:
        raise backend.DemoError('A 的游戏进程已不在运行，请重新启动演示')
    if CURRENT['mode']=='shared':
        b_stopped=CURRENT['b']['pid'] in result['killed_pids']
        if not b_stopped:
            raise backend.DemoError('未验证共享游戏 B 的停止状态')
        proof={'b_stopped':True,'verified':True}
    else:
        before=wait_local(9102)
        time.sleep(.4)
        after=wait_local(9102)
        proof={'b_stopped':False,'b_tick_before':before['tick'],'b_tick_after':after['tick'],'verified':after['tick']>before['tick']}
        if not proof['verified']:
            raise backend.DemoError('未验证独立游戏 B 的继续运行状态')
    CURRENT.update(state='faulted',fault={'killed_pids':result['killed_pids'],'execution_id':result['execution_id'],**proof},faulted_at=time.time())
    save_current()
    return CURRENT

def save_current():
    (HERE/'play'/'last-session.json').write_text(json.dumps(CURRENT))

def launch(action,mode):
    if action not in ('start','fault') or mode not in ('shared','isolated'):
        raise backend.DemoError('不支持的演示操作')
    if not GAME_LOCK.acquire(blocking=False):
        raise backend.DemoError('上一操作正在执行，请稍等')
    try:
        quota_path=backend.PRIVATE/'game-quota.json'
        day=time.strftime('%Y-%m-%d',time.gmtime())
        quota=json.loads(quota_path.read_text()) if quota_path.exists() else {}
        if quota.get('day')!=day:
            quota={'day':day,'count':0}
        if quota['count']>=100:
            raise backend.DemoError('今日演示操作次数已达上限')
        quota['count']+=1
        quota_path.write_text(json.dumps(quota))
        job=uuid.uuid4().hex
        GAME_JOBS[job]={'state':'running','message':'正在准备游戏环境','updated_at':time.time()}
        def run():
            try:
                def notify(message):
                    GAME_JOBS[job].update(message=message,updated_at=time.time())
                session=start_games(mode,notify) if action=='start' else fault_games(notify)
                GAME_JOBS[job]={'state':'done','session':session}
            except Exception as error:
                message=str(error) if isinstance(error,backend.DemoError) else '本次游戏操作未完成，请重新启动演示'
                GAME_JOBS[job]={'state':'error','message':message}
            finally:
                GAME_LOCK.release()
        threading.Thread(target=run,daemon=True).start()
        return job
    except Exception:
        GAME_LOCK.release()
        raise
