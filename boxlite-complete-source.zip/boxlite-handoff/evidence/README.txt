BoxLite Execution Lab：独立与不独立的实际运行对比

在线地址
https://8080-d-4e6a656b374551457035374d.proxy.boxlite.ai/isolation/

核心需求
面向允许 agent 运行代码的产品团队，展示多任务执行环境的边界。

90 秒演示顺序
1. 点击“重新运行真实实验”，等待 BoxLite 实际执行。
2. 切换“不独立”：A 和 B 共用同一个 Box，Box ID 相同。
3. 展开 agent_task.py、task_b.py 和 CSV。A 执行后，B 的测试文件被删除，B 自身的任务报错。
4. 切换“独立”：A 和 B 的 Box ID 不同，分别显示两台 microVM 内实际写入的代码和文件。
5. A 执行相同代码，无法读取或删除 B 的文件；A 的正常分析和 B 的任务均能完成。
6. 下载原始 JSON，查看真实运行 ID、执行 ID、时间、代码 SHA-256、文件内容和内核指纹。

事实边界
共享对照也运行在 BoxLite 内，只是两个任务放在同一个 Box；这样不会在本机演示越界代码。不是“用了 BoxLite 就安全、不用就不安全”。普通虚拟机和正确配置的权限也能隔离。这里展示 BoxLite 提供的独立执行环境与 API。
本版使用固定、可审计的 Python 脚本模拟 agent 的代码执行，不调用模型。仅操作新建测试目录内的虚构样本，不是漏洞逃逸或完整安全审计。没有网络开关实验。
界面中的文件是本次执行后采集的实际文件快照；不是可任意访问服务器的通用文件管理器。

运行架构
Box A：FouKpyrRRw8u，执行演示任务。
Box B：Njek7EQEp57M，承载可信调度服务与 B 的独立测试任务。
服务端通过 BoxLite REST API 调度 A，并保存实测证据。凭据在服务端 /home/boxlite/box-meaning-private/config.json 中，权限 600，位于网页服务目录外。用户已明确授权此用途。源码包不含密钥。
复用已有环境，不会在每次点击时创建新 Box。保留原闲置自动停止配置，冷启动可能需要等待。费用以 BoxLite 实际账单为准。

模型接口
isolation/model_adapter.py 预留 OpenAI-compatible 接口：MODEL_BASE_URL、MODEL_NAME、MODEL_API_KEY。用途是解释已验证证据；模型输出不会自动执行。当前未配置模型，也没有模型调用。

源码与复现
source/server.py：HTTP 服务与固定任务入口。
source/isolation/backend.py：真实 BoxLite 调度与证据采集。
source/isolation/experiment.py：写入并执行的固定脚本。
source/isolation/index.html / app.js / style.css：界面。
source/isolation/last-run.json：随交付附上的真实实测记录。
部署时将 source 下文件放在 /app，启动 python3 /app/server.py。
服务端私密配置字段：url、key、worker、controller、origin；需要使用你自己的密钥，不要把配置放进网页目录。

操作限制
仅支持固定测试任务，不接受任意代码或文件路径。单次运行互斥，设有冷却间隔和每日调用上限。数据、日志和代码均为演示样本。
